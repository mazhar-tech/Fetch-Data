import './App.css';
import React, { useEffect, useState } from 'react';

function App() {
  const [json,setJson]= useState([])
  var data;
  fetch('https://jsonplaceholder.typicode.com/users')
  .then(response => response.json())
  .then(json => data=json)

  function display() {
    setJson(data);
  }
  useEffect(()=>{
    setTimeout(()=>{
      setJson(data);
    }, 7000)
  }, [])

  return (
    <div>
     <div className="bg-light" style={{width:"100%",height:"100%",position:"absolute"}}>
    <div className="container bg-light">
    <table className="table mt-5 shadow-lg table-striped table-hover text ">
        <thead className=" text-dark">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Address</th>
            <th scope="col">Company</th>
            <th scope="col">View Profile</th>
          </tr>
        </thead>
        <tbody id="table">
          {json.map((data)=>(<tr key={data.id}>
       <th scope="row">{data.id}</th>
       <td>{data.name}</td>
       <td>{data.email}</td>
       <td>{data.address.street}, {data.address.city}, {data.address.zipcode}</td>
       <td>{data.company.name}</td>
       <td><a href="https://github.com/NawazishShah" onClick={display } className="btn btn-success" target="_blank" rel="noreferrer">View Profile</a></td>
     </tr>))}
  
     
        </tbody>
      </table>

      <button className="btn btn-success mt-5 mb-3 me-3" onClick={display}>Fetch Data</button>
     
     
</div>
   </div>
   </div>
  );
}

export default App;
